# Quick Reference Guide

## Common Tasks

### 1. First-Time Data Inspection

```bash
# Get an overview of your raw data
python scraper_inspector.py raw_data.jsonl --all

# Look at a few sample documents
python scraper_inspector.py raw_data.jsonl --sample 3
```

### 2. Clean and Validate Data

```bash
# Basic cleaning with auto-generated output filename
python scraper_cleaner.py raw_data.jsonl

# Clean with custom output path
python scraper_cleaner.py raw_data.jsonl -o corpus_v1.jsonl

# Just get statistics without saving output
python scraper_cleaner.py raw_data.jsonl --analysis-only
```

### 3. Filter Data by Criteria

```bash
# Keep only specific publishers
python scraper_utils.py filter-publisher data.jsonl filtered.jsonl cbsnews.com nytimes.com

# Exclude certain publishers
python scraper_utils.py filter-publisher data.jsonl filtered.jsonl spamsite.com --exclude

# Filter by date range
python scraper_utils.py filter-date data.jsonl filtered.jsonl --start 2025-10-01 --end 2025-10-31

# Filter by theme (documents with any of these themes)
python scraper_utils.py filter-theme data.jsonl filtered.jsonl CEASEFIRE TERROR

# Filter by theme (documents with ALL these themes)
python scraper_utils.py filter-theme data.jsonl filtered.jsonl CEASEFIRE ISRAEL --match-all

# Filter by location
python scraper_utils.py filter-location data.jsonl filtered.jsonl Israel Gaza
```

### 4. Merge Multiple Files

```bash
# Merge with deduplication (default)
python scraper_utils.py merge combined.jsonl file1.jsonl file2.jsonl file3.jsonl

# Merge without deduplication
python scraper_utils.py merge combined.jsonl file1.jsonl file2.jsonl --no-dedupe
```

### 5. Split Data

```bash
# Split by publisher (creates one file per publisher)
python scraper_utils.py split data.jsonl output_dir/ publisher

# Split by source type
python scraper_utils.py split data.jsonl output_dir/ source_type

# Split by any other field
python scraper_utils.py split data.jsonl output_dir/ extraction_method
```

### 6. Extract Specific Fields

```bash
# Create lightweight version with only essential fields
python scraper_utils.py extract data.jsonl lightweight.jsonl url title content published_at

# Extract just metadata
python scraper_utils.py extract data.jsonl metadata.jsonl url publisher published_at themes locations
```

### 7. Sample Data

```bash
# Random sample of 100 documents
python scraper_utils.py sample data.jsonl sample_100.jsonl 100

# First 100 documents (sequential)
python scraper_utils.py sample data.jsonl first_100.jsonl 100 --sequential
```

## Complete Workflows

### Workflow 1: Basic Data Cleaning Pipeline

```bash
# 1. Inspect raw data
python scraper_inspector.py raw_data.jsonl --all

# 2. Clean and validate
python scraper_cleaner.py raw_data.jsonl -o clean_data.jsonl

# 3. Verify cleaning
python scraper_inspector.py clean_data.jsonl --quality

# 4. Check for remaining issues
python scraper_inspector.py clean_data.jsonl --malformed
```

### Workflow 2: Merge and Filter Multiple Sources

```bash
# 1. Merge multiple scraping runs
python scraper_utils.py merge all_data.jsonl run1.jsonl run2.jsonl run3.jsonl

# 2. Clean merged data
python scraper_cleaner.py all_data.jsonl -o clean_all.jsonl

# 3. Filter to specific date range
python scraper_utils.py filter-date clean_all.jsonl october_data.jsonl \
    --start 2025-10-01 --end 2025-10-31

# 4. Verify final dataset
python scraper_inspector.py october_data.jsonl --all
```

### Workflow 3: Create Analysis Subsets

```bash
# 1. Clean full dataset
python scraper_cleaner.py full_data.jsonl -o clean_full.jsonl

# 2. Create subset for specific publishers
python scraper_utils.py filter-publisher clean_full.jsonl mainstream.jsonl \
    nytimes.com washingtonpost.com cbsnews.com

# 3. Create subset for specific themes
python scraper_utils.py filter-theme clean_full.jsonl terrorism_subset.jsonl \
    TERROR WB_2467_TERRORISM

# 4. Create subset for specific locations
python scraper_utils.py filter-location clean_full.jsonl israel_subset.jsonl \
    Israel Gaza "West Bank"

# 5. Create random sample for testing
python scraper_utils.py sample clean_full.jsonl test_sample.jsonl 500
```

### Workflow 4: Quality Control

```bash
# 1. Initial quality check
python scraper_inspector.py raw_data.jsonl --malformed > issues.txt

# 2. Clean data
python scraper_cleaner.py raw_data.jsonl -o v1_clean.jsonl

# 3. Check field coverage
python scraper_inspector.py v1_clean.jsonl --coverage

# 4. Extract only complete documents (those with all key metadata)
python scraper_utils.py extract v1_clean.jsonl v2_complete.jsonl \
    url title content publisher author published_at themes locations

# 5. Final verification
python scraper_inspector.py v2_complete.jsonl --all
```

### Workflow 5: Prepare for Belief Transformer

```bash
# 1. Clean and validate
python scraper_cleaner.py scraped_news.jsonl -o clean_news.jsonl

# 2. Filter to relevant topics
python scraper_utils.py filter-theme clean_news.jsonl relevant.jsonl \
    WB_2462_POLITICAL_VIOLENCE_AND_WAR CEASEFIRE

# 3. Filter date range
python scraper_utils.py filter-date relevant.jsonl dated.jsonl \
    --start 2025-10-01 --end 2025-10-31

# 4. Extract fields needed for analysis
python scraper_utils.py extract dated.jsonl for_analysis.jsonl \
    url title content publisher published_at sentiment_score

# 5. Verify final dataset
python scraper_inspector.py for_analysis.jsonl --all
```

## Cheat Sheet

### Inspection Commands

| Command | Purpose |
|---------|---------|
| `--all` | Show all reports |
| `--coverage` | Field coverage percentage |
| `--quality` | Extraction quality metrics |
| `--malformed` | Detect content issues |
| `--sample N` | View N random documents |

### Utility Commands

| Command | Purpose |
|---------|---------|
| `filter-date` | Filter by date range |
| `filter-publisher` | Filter by publisher domain |
| `filter-theme` | Filter by theme tags |
| `filter-location` | Filter by location mentions |
| `merge` | Combine multiple files |
| `split` | Split by field value |
| `extract` | Keep only specific fields |
| `sample` | Random or sequential sample |

### Common Flags

| Flag | Purpose |
|------|---------|
| `-o`, `--output` | Specify output file |
| `--analysis-only` | Don't save output |
| `--exclude` | Inverse filter |
| `--match-all` | Require all criteria |
| `--no-dedupe` | Skip deduplication |
| `--sequential` | Sequential instead of random |

## Tips and Tricks

### Performance

- Scripts are memory-efficient and stream data
- Large files (>1GB) process fine
- Deduplication requires storing IDs in memory

### Combining Operations

```bash
# Chain operations with intermediate files
python scraper_cleaner.py raw.jsonl -o step1.jsonl
python scraper_utils.py filter-date step1.jsonl step2.jsonl --start 2025-10-01
python scraper_utils.py filter-theme step2.jsonl final.jsonl TERRORISM
rm step1.jsonl step2.jsonl  # Clean up intermediate files
```

### Quick Stats

```bash
# Count documents
wc -l data.jsonl

# View first document (pretty-printed)
head -1 data.jsonl | python -m json.tool

# Count unique publishers
grep -o '"publisher":"[^"]*"' data.jsonl | sort | uniq -c
```

### Debugging

```bash
# Check for JSON errors
python -c "
import json
with open('data.jsonl') as f:
    for i, line in enumerate(f, 1):
        try:
            json.loads(line)
        except json.JSONDecodeError as e:
            print(f'Line {i}: {e}')
"
```

### Backup Strategy

```bash
# Always keep original
cp raw_data.jsonl raw_data.backup.jsonl

# Version cleaned data
python scraper_cleaner.py raw_data.jsonl -o corpus_v1_$(date +%Y%m%d).jsonl
```

## Troubleshooting

### "No such file or directory"
- Check file paths are correct
- Use absolute paths if relative paths fail

### "Invalid JSON"
- Check source file has proper JSONL format (one JSON per line)
- Use inspector to identify problematic lines

### "Memory error" 
- Split file into chunks first
- Process chunks separately then merge

### "Permission denied"
- Make scripts executable: `chmod +x *.py`
- Check output directory write permissions

### "Empty output file"
- Check filter criteria aren't too restrictive
- Use `--analysis-only` first to see what would be kept

## Getting Help

```bash
# General help
python scraper_cleaner.py --help
python scraper_inspector.py --help
python scraper_utils.py --help

# Command-specific help
python scraper_utils.py filter-date --help
python scraper_utils.py merge --help
```
