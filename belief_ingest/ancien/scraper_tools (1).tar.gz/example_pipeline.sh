#!/bin/bash
# example_pipeline.sh
#
# Example pipeline for processing your news scraper output
# This demonstrates a complete workflow from raw data to clean corpus

set -e  # Exit on error

echo "=========================================="
echo "NEWS SCRAPER CLEANING PIPELINE"
echo "=========================================="
echo

# Configuration
INPUT_FILE="scraped_news.jsonl"
OUTPUT_DIR="cleaned_output"
DATE_START="2025-10-01"
DATE_END="2025-10-31"

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Step 1: Initial Inspection
echo "Step 1: Inspecting raw data..."
python3 scraper_inspector.py "$INPUT_FILE" --all > "$OUTPUT_DIR/01_initial_inspection.txt"
echo "✅ Inspection report saved to: $OUTPUT_DIR/01_initial_inspection.txt"
echo

# Step 2: Clean and Validate
echo "Step 2: Cleaning and validating documents..."
python3 scraper_cleaner.py "$INPUT_FILE" -o "$OUTPUT_DIR/02_cleaned.jsonl" \
    > "$OUTPUT_DIR/02_cleaning_report.txt"
echo "✅ Cleaned data: $OUTPUT_DIR/02_cleaned.jsonl"
echo "✅ Cleaning report: $OUTPUT_DIR/02_cleaning_report.txt"
echo

# Step 3: Filter by Date Range
echo "Step 3: Filtering to date range $DATE_START to $DATE_END..."
python3 scraper_utils.py filter-date \
    "$OUTPUT_DIR/02_cleaned.jsonl" \
    "$OUTPUT_DIR/03_dated.jsonl" \
    --start "$DATE_START" --end "$DATE_END"
echo "✅ Date-filtered data: $OUTPUT_DIR/03_dated.jsonl"
echo

# Step 4: Filter to Relevant Themes
echo "Step 4: Filtering to relevant themes..."
# Topics related to conflict, terrorism, and political events
python3 scraper_utils.py filter-theme \
    "$OUTPUT_DIR/03_dated.jsonl" \
    "$OUTPUT_DIR/04_themed.jsonl" \
    WB_2462_POLITICAL_VIOLENCE_AND_WAR \
    WB_2467_TERRORISM \
    CEASEFIRE \
    TAX_TERROR_GROUP_HAMAS
echo "✅ Theme-filtered data: $OUTPUT_DIR/04_themed.jsonl"
echo

# Step 5: Split by Publisher (for observer analysis)
echo "Step 5: Splitting by publisher..."
python3 scraper_utils.py split \
    "$OUTPUT_DIR/04_themed.jsonl" \
    "$OUTPUT_DIR/05_by_publisher" \
    publisher
echo "✅ Split by publisher: $OUTPUT_DIR/05_by_publisher/"
echo

# Step 6: Extract Fields for Analysis
echo "Step 6: Extracting fields for Belief Transformer..."
python3 scraper_utils.py extract \
    "$OUTPUT_DIR/04_themed.jsonl" \
    "$OUTPUT_DIR/06_for_analysis.jsonl" \
    url title content publisher published_at themes locations sentiment_score
echo "✅ Extracted fields: $OUTPUT_DIR/06_for_analysis.jsonl"
echo

# Step 7: Create Sample for Testing
echo "Step 7: Creating test sample (100 documents)..."
python3 scraper_utils.py sample \
    "$OUTPUT_DIR/06_for_analysis.jsonl" \
    "$OUTPUT_DIR/07_test_sample.jsonl" \
    100
echo "✅ Test sample: $OUTPUT_DIR/07_test_sample.jsonl"
echo

# Step 8: Final Quality Check
echo "Step 8: Final quality verification..."
python3 scraper_inspector.py "$OUTPUT_DIR/06_for_analysis.jsonl" --all \
    > "$OUTPUT_DIR/08_final_report.txt"
echo "✅ Final report: $OUTPUT_DIR/08_final_report.txt"
echo

# Summary
echo "=========================================="
echo "PIPELINE COMPLETE"
echo "=========================================="
echo
echo "Output files:"
echo "  1. Initial inspection:    $OUTPUT_DIR/01_initial_inspection.txt"
echo "  2. Cleaned corpus:        $OUTPUT_DIR/02_cleaned.jsonl"
echo "  3. Date-filtered:         $OUTPUT_DIR/03_dated.jsonl"
echo "  4. Theme-filtered:        $OUTPUT_DIR/04_themed.jsonl"
echo "  5. By publisher:          $OUTPUT_DIR/05_by_publisher/"
echo "  6. For analysis:          $OUTPUT_DIR/06_for_analysis.jsonl"
echo "  7. Test sample:           $OUTPUT_DIR/07_test_sample.jsonl"
echo "  8. Final report:          $OUTPUT_DIR/08_final_report.txt"
echo
echo "The main output for Belief Transformer is:"
echo "  → $OUTPUT_DIR/06_for_analysis.jsonl"
echo
echo "Publisher-specific data for observer analysis:"
echo "  → $OUTPUT_DIR/05_by_publisher/*.jsonl"
echo

# Display final statistics
if [ -f "$OUTPUT_DIR/08_final_report.txt" ]; then
    echo "Quick Statistics:"
    grep -A 5 "CORPUS ANALYSIS:" "$OUTPUT_DIR/08_final_report.txt" || true
fi

echo
echo "Done! 🎉"
