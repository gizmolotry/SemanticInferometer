#!/usr/bin/env python3
"""
Test script to verify scraper tools work correctly.
Creates sample data and runs all operations.
"""

import json
import os
import subprocess
from pathlib import Path


def create_test_data():
    """Create sample test data file."""
    test_data = [
        {
            "url": "https://example1.com/article1",
            "publisher": "example1.com",
            "source_type": "test",
            "published_at": "2025-10-05",
            "title": "Test Article 1",
            "author": "Test Author 1",
            "content": "This is the content of test article 1. It has enough words to be meaningful.",
            "word_count": 15,
            "char_count": 80,
            "themes": ["THEME1", "THEME2"],
            "locations": ["Location1"],
            "sentiment_score": 2.5,
            "extraction_method": "test",
            "id": "test1"
        },
        {
            "url": "https://example2.com/article2",
            "publisher": "example2.com",
            "source_type": "test",
            "published_at": "2025-10-06",
            "title": "Test Article 2",
            "author": "Test Author 2",
            "content": "This is the content of test article 2. It also has sufficient content for testing.",
            "word_count": 16,
            "char_count": 85,
            "themes": ["THEME2", "THEME3"],
            "locations": ["Location2"],
            "sentiment_score": -1.5,
            "extraction_method": "test",
            "id": "test2"
        },
        {
            "url": "https://example1.com/article3",
            "publisher": "example1.com",
            "source_type": "test",
            "published_at": "2025-10-07",
            "title": "Test Article 3",
            "content": "Duplicate content for testing deduplication.",
            "word_count": 6,
            "char_count": 45,
            "themes": ["THEME1"],
            "locations": ["Location1", "Location2"],
            "sentiment_score": 0.0,
            "extraction_method": "test",
            "id": "test3"
        },
        {
            "url": "https://example1.com/article3",  # Duplicate URL
            "publisher": "example1.com",
            "source_type": "test",
            "published_at": "2025-10-07",
            "title": "Test Article 3 (Duplicate)",
            "content": "Duplicate content for testing deduplication.",  # Duplicate content
            "word_count": 6,
            "char_count": 45,
            "themes": ["THEME1"],
            "locations": ["Location1"],
            "sentiment_score": 0.0,
            "extraction_method": "test",
            "id": "test3"  # Duplicate ID
        }
    ]
    
    test_file = "test_data.jsonl"
    with open(test_file, 'w', encoding='utf-8') as f:
        for doc in test_data:
            f.write(json.dumps(doc) + '\n')
    
    print(f"✅ Created test data: {test_file}")
    return test_file


def run_command(cmd, description):
    """Run a command and report results."""
    print(f"\n{'='*70}")
    print(f"TEST: {description}")
    print(f"{'='*70}")
    print(f"Command: {' '.join(cmd)}")
    print()
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        
        if result.returncode == 0:
            print(f"✅ PASS: {description}")
            return True
        else:
            print(f"❌ FAIL: {description} (exit code {result.returncode})")
            return False
    except subprocess.TimeoutExpired:
        print(f"❌ FAIL: {description} (timeout)")
        return False
    except Exception as e:
        print(f"❌ FAIL: {description} ({e})")
        return False


def verify_file_exists(filepath, description):
    """Verify a file was created."""
    if Path(filepath).exists():
        size = Path(filepath).stat().st_size
        print(f"✅ File created: {filepath} ({size} bytes)")
        return True
    else:
        print(f"❌ File not created: {filepath}")
        return False


def main():
    """Run all tests."""
    print("="*70)
    print("SCRAPER TOOLS TEST SUITE")
    print("="*70)
    
    # Create test data
    test_file = create_test_data()
    
    results = []
    
    # Test 1: Inspector - All reports
    results.append(run_command(
        ["python3", "scraper_inspector.py", test_file, "--all"],
        "Inspector: Show all reports"
    ))
    
    # Test 2: Inspector - Coverage only
    results.append(run_command(
        ["python3", "scraper_inspector.py", test_file, "--coverage"],
        "Inspector: Coverage report"
    ))
    
    # Test 3: Inspector - Sample
    results.append(run_command(
        ["python3", "scraper_inspector.py", test_file, "--sample", "2"],
        "Inspector: Sample documents"
    ))
    
    # Test 4: Cleaner - Basic cleaning
    results.append(run_command(
        ["python3", "scraper_cleaner.py", test_file, "-o", "test_clean.jsonl"],
        "Cleaner: Basic cleaning"
    ))
    results.append(verify_file_exists("test_clean.jsonl", "Cleaned output"))
    
    # Test 5: Cleaner - Analysis only
    results.append(run_command(
        ["python3", "scraper_cleaner.py", test_file, "--analysis-only"],
        "Cleaner: Analysis only mode"
    ))
    
    # Test 6: Utils - Filter by publisher
    results.append(run_command(
        ["python3", "scraper_utils.py", "filter-publisher", 
         test_file, "test_pub_filter.jsonl", "example1.com"],
        "Utils: Filter by publisher"
    ))
    results.append(verify_file_exists("test_pub_filter.jsonl", "Publisher filter output"))
    
    # Test 7: Utils - Filter by date
    results.append(run_command(
        ["python3", "scraper_utils.py", "filter-date",
         test_file, "test_date_filter.jsonl", "--start", "2025-10-06"],
        "Utils: Filter by date"
    ))
    results.append(verify_file_exists("test_date_filter.jsonl", "Date filter output"))
    
    # Test 8: Utils - Filter by theme
    results.append(run_command(
        ["python3", "scraper_utils.py", "filter-theme",
         test_file, "test_theme_filter.jsonl", "THEME1"],
        "Utils: Filter by theme"
    ))
    results.append(verify_file_exists("test_theme_filter.jsonl", "Theme filter output"))
    
    # Test 9: Utils - Merge files
    results.append(run_command(
        ["python3", "scraper_utils.py", "merge",
         "test_merged.jsonl", test_file, "test_clean.jsonl"],
        "Utils: Merge files"
    ))
    results.append(verify_file_exists("test_merged.jsonl", "Merged output"))
    
    # Test 10: Utils - Extract fields
    results.append(run_command(
        ["python3", "scraper_utils.py", "extract",
         test_file, "test_extract.jsonl", "url", "title", "content"],
        "Utils: Extract fields"
    ))
    results.append(verify_file_exists("test_extract.jsonl", "Extract output"))
    
    # Test 11: Utils - Sample documents
    results.append(run_command(
        ["python3", "scraper_utils.py", "sample",
         test_file, "test_sample.jsonl", "2"],
        "Utils: Sample documents"
    ))
    results.append(verify_file_exists("test_sample.jsonl", "Sample output"))
    
    # Test 12: Utils - Split by field
    os.makedirs("test_split_output", exist_ok=True)
    results.append(run_command(
        ["python3", "scraper_utils.py", "split",
         test_file, "test_split_output", "publisher"],
        "Utils: Split by field"
    ))
    
    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    
    passed = sum(results)
    total = len(results)
    
    print(f"\nPassed: {passed}/{total} tests")
    
    if passed == total:
        print("\n🎉 All tests passed!")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
    
    # Cleanup
    print("\n" + "="*70)
    print("CLEANUP")
    print("="*70)
    print("\nTest files created:")
    test_files = [
        test_file,
        "test_clean.jsonl",
        "test_pub_filter.jsonl",
        "test_date_filter.jsonl",
        "test_theme_filter.jsonl",
        "test_merged.jsonl",
        "test_extract.jsonl",
        "test_sample.jsonl"
    ]
    
    for f in test_files:
        if Path(f).exists():
            print(f"  - {f}")
    
    if Path("test_split_output").exists():
        print(f"  - test_split_output/ (directory)")
    
    print("\nTo clean up test files, run:")
    print("  rm test_*.jsonl")
    print("  rm -r test_split_output")
    
    return 0 if passed == total else 1


if __name__ == '__main__':
    import sys
    sys.exit(main())
