#!/usr/bin/env python3
"""
Scraper Data Utilities

Common operations for manipulating and transforming scraped data.
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Set
from datetime import datetime


def filter_by_date_range(input_file: str, output_file: str, 
                         start_date: str = None, end_date: str = None) -> int:
    """
    Filter documents by date range.
    
    Args:
        input_file: Input JSONL file
        output_file: Output JSONL file
        start_date: Start date (YYYY-MM-DD), inclusive
        end_date: End date (YYYY-MM-DD), inclusive
    
    Returns:
        Number of documents written
    """
    count = 0
    
    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
            
            try:
                doc = json.loads(line)
                pub_date = doc.get('published_at', '')
                
                if not pub_date:
                    continue
                
                # Extract just the date part
                date_part = pub_date.split('T')[0]
                
                if start_date and date_part < start_date:
                    continue
                
                if end_date and date_part > end_date:
                    continue
                
                fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                count += 1
                
            except (json.JSONDecodeError, KeyError):
                continue
    
    print(f"✅ Filtered {count} documents to {output_file}")
    return count


def filter_by_publisher(input_file: str, output_file: str, 
                        publishers: List[str], exclude: bool = False) -> int:
    """
    Filter documents by publisher.
    
    Args:
        input_file: Input JSONL file
        output_file: Output JSONL file
        publishers: List of publisher domains
        exclude: If True, exclude these publishers; if False, include only these
    
    Returns:
        Number of documents written
    """
    publishers_set = set(pub.lower() for pub in publishers)
    count = 0
    
    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
            
            try:
                doc = json.loads(line)
                pub = doc.get('publisher', '').lower()
                
                if exclude:
                    if pub not in publishers_set:
                        fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                        count += 1
                else:
                    if pub in publishers_set:
                        fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                        count += 1
                
            except json.JSONDecodeError:
                continue
    
    print(f"✅ Filtered {count} documents to {output_file}")
    return count


def filter_by_theme(input_file: str, output_file: str, 
                    themes: List[str], match_all: bool = False) -> int:
    """
    Filter documents by themes.
    
    Args:
        input_file: Input JSONL file
        output_file: Output JSONL file
        themes: List of theme strings to match
        match_all: If True, document must have all themes; if False, any theme
    
    Returns:
        Number of documents written
    """
    themes_set = set(theme.upper() for theme in themes)
    count = 0
    
    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
            
            try:
                doc = json.loads(line)
                doc_themes = set(theme.upper() for theme in doc.get('themes', []))
                
                if match_all:
                    if themes_set.issubset(doc_themes):
                        fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                        count += 1
                else:
                    if themes_set.intersection(doc_themes):
                        fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                        count += 1
                
            except json.JSONDecodeError:
                continue
    
    print(f"✅ Filtered {count} documents to {output_file}")
    return count


def filter_by_location(input_file: str, output_file: str, 
                       locations: List[str]) -> int:
    """
    Filter documents that mention specific locations.
    
    Args:
        input_file: Input JSONL file
        output_file: Output JSONL file
        locations: List of location strings to match (case-insensitive)
    
    Returns:
        Number of documents written
    """
    locations_set = set(loc.lower() for loc in locations)
    count = 0
    
    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
            
            try:
                doc = json.loads(line)
                doc_locs = set(loc.lower() for loc in doc.get('locations', []))
                
                if locations_set.intersection(doc_locs):
                    fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                    count += 1
                
            except json.JSONDecodeError:
                continue
    
    print(f"✅ Filtered {count} documents to {output_file}")
    return count


def merge_files(input_files: List[str], output_file: str, 
                deduplicate: bool = True) -> int:
    """
    Merge multiple JSONL files.
    
    Args:
        input_files: List of input JSONL files
        output_file: Output JSONL file
        deduplicate: If True, remove duplicates by ID
    
    Returns:
        Number of documents written
    """
    seen_ids = set()
    count = 0
    
    with open(output_file, 'w', encoding='utf-8') as fout:
        for input_file in input_files:
            print(f"Processing {input_file}...")
            
            with open(input_file, 'r', encoding='utf-8') as fin:
                for line in fin:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        doc = json.loads(line)
                        
                        if deduplicate:
                            doc_id = doc.get('id')
                            if doc_id and doc_id in seen_ids:
                                continue
                            if doc_id:
                                seen_ids.add(doc_id)
                        
                        fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                        count += 1
                        
                    except json.JSONDecodeError:
                        continue
    
    print(f"✅ Merged {count} documents to {output_file}")
    return count


def split_by_field(input_file: str, output_dir: str, field: str) -> Dict[str, int]:
    """
    Split documents into separate files based on a field value.
    
    Args:
        input_file: Input JSONL file
        output_dir: Output directory for split files
        field: Field name to split on (e.g., 'publisher', 'source_type')
    
    Returns:
        Dictionary mapping field values to document counts
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    counts = {}
    file_handles = {}
    
    try:
        with open(input_file, 'r', encoding='utf-8') as fin:
            for line in fin:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    doc = json.loads(line)
                    field_value = doc.get(field, 'unknown')
                    
                    # Sanitize filename
                    safe_value = str(field_value).replace('/', '_').replace('\\', '_')
                    
                    if field_value not in file_handles:
                        output_file = output_path / f"{field}_{safe_value}.jsonl"
                        file_handles[field_value] = open(output_file, 'w', encoding='utf-8')
                        counts[field_value] = 0
                    
                    file_handles[field_value].write(json.dumps(doc, ensure_ascii=False) + '\n')
                    counts[field_value] += 1
                    
                except json.JSONDecodeError:
                    continue
    
    finally:
        for fh in file_handles.values():
            fh.close()
    
    print(f"✅ Split documents by {field}:")
    for value, count in sorted(counts.items(), key=lambda x: x[1], reverse=True):
        print(f"  {value}: {count} documents")
    
    return counts


def extract_fields(input_file: str, output_file: str, 
                   fields: List[str]) -> int:
    """
    Extract only specific fields from documents.
    
    Args:
        input_file: Input JSONL file
        output_file: Output JSONL file
        fields: List of field names to keep
    
    Returns:
        Number of documents written
    """
    count = 0
    
    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
            
            try:
                doc = json.loads(line)
                extracted = {field: doc.get(field) for field in fields if field in doc}
                
                fout.write(json.dumps(extracted, ensure_ascii=False) + '\n')
                count += 1
                
            except json.JSONDecodeError:
                continue
    
    print(f"✅ Extracted {len(fields)} fields from {count} documents")
    return count


def sample_documents(input_file: str, output_file: str, n: int, 
                     random: bool = True) -> int:
    """
    Sample N documents from input file.
    
    Args:
        input_file: Input JSONL file
        output_file: Output JSONL file
        n: Number of documents to sample
        random: If True, sample randomly; if False, take first N
    
    Returns:
        Number of documents written
    """
    import random as rand
    
    if random:
        # Load all documents for random sampling
        docs = []
        with open(input_file, 'r', encoding='utf-8') as fin:
            for line in fin:
                line = line.strip()
                if line:
                    try:
                        docs.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        
        if len(docs) <= n:
            sampled = docs
        else:
            sampled = rand.sample(docs, n)
        
        with open(output_file, 'w', encoding='utf-8') as fout:
            for doc in sampled:
                fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
        
        count = len(sampled)
    else:
        # Sequential sampling
        count = 0
        with open(input_file, 'r', encoding='utf-8') as fin, \
             open(output_file, 'w', encoding='utf-8') as fout:
            
            for line in fin:
                if count >= n:
                    break
                
                line = line.strip()
                if not line:
                    continue
                
                try:
                    doc = json.loads(line)
                    fout.write(json.dumps(doc, ensure_ascii=False) + '\n')
                    count += 1
                except json.JSONDecodeError:
                    continue
    
    print(f"✅ Sampled {count} documents to {output_file}")
    return count


def main():
    """Command-line interface for data utilities."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Utilities for manipulating scraped data'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Filter by date
    date_parser = subparsers.add_parser('filter-date', help='Filter by date range')
    date_parser.add_argument('input', help='Input file')
    date_parser.add_argument('output', help='Output file')
    date_parser.add_argument('--start', help='Start date (YYYY-MM-DD)')
    date_parser.add_argument('--end', help='End date (YYYY-MM-DD)')
    
    # Filter by publisher
    pub_parser = subparsers.add_parser('filter-publisher', help='Filter by publisher')
    pub_parser.add_argument('input', help='Input file')
    pub_parser.add_argument('output', help='Output file')
    pub_parser.add_argument('publishers', nargs='+', help='Publisher domains')
    pub_parser.add_argument('--exclude', action='store_true', help='Exclude publishers')
    
    # Filter by theme
    theme_parser = subparsers.add_parser('filter-theme', help='Filter by theme')
    theme_parser.add_argument('input', help='Input file')
    theme_parser.add_argument('output', help='Output file')
    theme_parser.add_argument('themes', nargs='+', help='Theme strings')
    theme_parser.add_argument('--match-all', action='store_true', help='Require all themes')
    
    # Filter by location
    loc_parser = subparsers.add_parser('filter-location', help='Filter by location')
    loc_parser.add_argument('input', help='Input file')
    loc_parser.add_argument('output', help='Output file')
    loc_parser.add_argument('locations', nargs='+', help='Location strings')
    
    # Merge files
    merge_parser = subparsers.add_parser('merge', help='Merge multiple files')
    merge_parser.add_argument('output', help='Output file')
    merge_parser.add_argument('inputs', nargs='+', help='Input files')
    merge_parser.add_argument('--no-dedupe', action='store_true', help='Skip deduplication')
    
    # Split by field
    split_parser = subparsers.add_parser('split', help='Split by field value')
    split_parser.add_argument('input', help='Input file')
    split_parser.add_argument('output_dir', help='Output directory')
    split_parser.add_argument('field', help='Field to split on')
    
    # Extract fields
    extract_parser = subparsers.add_parser('extract', help='Extract specific fields')
    extract_parser.add_argument('input', help='Input file')
    extract_parser.add_argument('output', help='Output file')
    extract_parser.add_argument('fields', nargs='+', help='Fields to extract')
    
    # Sample documents
    sample_parser = subparsers.add_parser('sample', help='Sample documents')
    sample_parser.add_argument('input', help='Input file')
    sample_parser.add_argument('output', help='Output file')
    sample_parser.add_argument('n', type=int, help='Number of documents')
    sample_parser.add_argument('--sequential', action='store_true', help='Sequential (not random)')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Execute command
    if args.command == 'filter-date':
        filter_by_date_range(args.input, args.output, args.start, args.end)
    
    elif args.command == 'filter-publisher':
        filter_by_publisher(args.input, args.output, args.publishers, args.exclude)
    
    elif args.command == 'filter-theme':
        filter_by_theme(args.input, args.output, args.themes, args.match_all)
    
    elif args.command == 'filter-location':
        filter_by_location(args.input, args.output, args.locations)
    
    elif args.command == 'merge':
        merge_files(args.inputs, args.output, not args.no_dedupe)
    
    elif args.command == 'split':
        split_by_field(args.input, args.output_dir, args.field)
    
    elif args.command == 'extract':
        extract_fields(args.input, args.output, args.fields)
    
    elif args.command == 'sample':
        sample_documents(args.input, args.output, args.n, not args.sequential)


if __name__ == '__main__':
    main()
