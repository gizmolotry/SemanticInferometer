# Scraper Cleaning Tools - Complete Index

## 🎯 Start Here

**New users**: Start with **OVERVIEW.md** for a complete introduction, then read **QUICKSTART.md** for practical examples.

**Existing users**: Jump directly to **QUICKSTART.md** for common commands, or run `python3 test_tools.py` to verify your installation.

## 📚 Documentation Files

### OVERVIEW.md (8.8KB)
**Read this first!**
- Complete package introduction
- Feature list and capabilities
- Installation instructions
- Real-world examples
- Use cases for Belief Transformer project
- Performance benchmarks
- Best practices

### QUICKSTART.md (8.3KB)
**Your daily reference**
- Common tasks with copy-paste commands
- Complete workflows (5 examples)
- Command cheat sheet
- Tips and tricks
- Troubleshooting guide

### README.md (9.5KB)
**Comprehensive manual**
- Detailed usage instructions
- Data format specifications
- All cleaning operations explained
- Quality check descriptions
- Example outputs and reports
- Integration patterns

## 🛠️ Script Files

### scraper_cleaner.py (16KB) ⭐
**Main cleaning engine**

**Purpose**: Clean, validate, and deduplicate scraped documents

**Key Functions**:
- Load and validate JSONL documents
- Check required fields (url, content, title)
- Deduplicate by ID and content hash
- Normalize text (whitespace, encoding)
- Validate dates, numbers, sentiment scores
- Generate comprehensive statistics
- Export cleaned corpus

**Usage**:
```bash
# Basic cleaning
python3 scraper_cleaner.py input.jsonl

# Custom output
python3 scraper_cleaner.py input.jsonl -o clean.jsonl

# Analysis only
python3 scraper_cleaner.py input.jsonl --analysis-only
```

**When to use**: Always run this first on raw scraper output

---

### scraper_inspector.py (14KB) ⭐
**Quality inspection tool**

**Purpose**: Analyze data quality and identify issues

**Key Functions**:
- Field coverage percentage (visual bars)
- Extraction quality metrics
- Content length distribution
- Malformed content detection
- Sample document viewer
- Theme/location frequency analysis

**Usage**:
```bash
# All reports
python3 scraper_inspector.py data.jsonl --all

# Specific reports
python3 scraper_inspector.py data.jsonl --coverage
python3 scraper_inspector.py data.jsonl --quality
python3 scraper_inspector.py data.jsonl --malformed

# View samples
python3 scraper_inspector.py data.jsonl --sample 10
```

**When to use**: 
- Before cleaning (understand raw data)
- After cleaning (verify results)
- When debugging extraction issues

---

### scraper_utils.py (17KB) ⭐
**Data manipulation toolkit**

**Purpose**: Filter, merge, split, and transform data

**Key Functions**:
- Filter by date range
- Filter by publisher (include/exclude)
- Filter by themes (any/all)
- Filter by locations
- Merge multiple files (with deduplication)
- Split by field values
- Extract specific fields
- Sample documents (random/sequential)

**Usage**:
```bash
# Filter operations
python3 scraper_utils.py filter-date in.jsonl out.jsonl --start 2025-10-01
python3 scraper_utils.py filter-publisher in.jsonl out.jsonl nyt.com wsj.com
python3 scraper_utils.py filter-theme in.jsonl out.jsonl TERRORISM CONFLICT
python3 scraper_utils.py filter-location in.jsonl out.jsonl Israel Gaza

# Data operations
python3 scraper_utils.py merge out.jsonl file1.jsonl file2.jsonl file3.jsonl
python3 scraper_utils.py split in.jsonl output_dir/ publisher
python3 scraper_utils.py extract in.jsonl out.jsonl url title content
python3 scraper_utils.py sample in.jsonl out.jsonl 1000
```

**When to use**: After cleaning, for preparing specific datasets

---

### test_tools.py (8.5KB)
**Automated test suite**

**Purpose**: Verify all tools work correctly

**What it does**:
- Creates sample test data
- Runs 19 comprehensive tests
- Tests all major functions
- Verifies file creation
- Reports pass/fail for each test

**Usage**:
```bash
python3 test_tools.py
```

**When to use**:
- After installation
- After making changes
- When troubleshooting issues
- Before processing important data

---

### example_pipeline.sh (4.1KB)
**Complete workflow example**

**Purpose**: Demonstrate end-to-end data processing

**What it does**:
1. Inspect raw data
2. Clean and validate
3. Filter by date
4. Filter by theme
5. Split by publisher
6. Extract fields for analysis
7. Create test sample
8. Generate final report

**Usage**:
```bash
# Edit INPUT_FILE variable first, then:
./example_pipeline.sh
```

**When to use**: As a template for your own pipelines

## 📊 Output Examples

### Cleaning Report
```
📊 PROCESSING STATISTICS:
  Total documents processed:     1000
  Valid documents:               950
  Duplicates removed:            45
  Missing required fields:       5
  Invalid dates:                 2
  
📈 CORPUS ANALYSIS:
  Final document count:          950
  Average word count:            645.5
  Average character count:       4012.8
  Date range:                    2025-05-11 to 2025-10-06
```

### Field Coverage
```
url                     ██████████████████████████████ 100.00%
content                 ██████████████████████████████ 100.00%
title                   ██████████████████████████████ 100.00%
publisher               ███████████████████████████░░░  92.31%
published_at            ████████████████████████░░░░░░  84.62%
```

### Quality Metrics
```
📏 CONTENT METRICS:
  Average content length:  4012 chars
  Average word count:      645 words
  Documents with snippets: 850
  Documents with metadata: 920

📊 CONTENT LENGTH DISTRIBUTION:
  very_short       50 (  5.3%)
  short           150 ( 15.8%)
  medium          600 ( 63.2%)
  long            120 ( 12.6%)
  very_long        30 (  3.1%)
```

## 🔄 Typical Workflow

### 1. First Time Setup
```bash
# Verify installation
python3 test_tools.py
```

### 2. Inspect Raw Data
```bash
python3 scraper_inspector.py raw_data.jsonl --all
```

### 3. Clean Data
```bash
python3 scraper_cleaner.py raw_data.jsonl -o clean_data.jsonl
```

### 4. Filter to Subset
```bash
# By date
python3 scraper_utils.py filter-date clean_data.jsonl dated.jsonl \
    --start 2025-10-01 --end 2025-10-31

# By theme
python3 scraper_utils.py filter-theme dated.jsonl themed.jsonl \
    CONFLICT CEASEFIRE

# By publisher
python3 scraper_utils.py filter-publisher themed.jsonl final.jsonl \
    reputable1.com reputable2.com reputable3.com
```

### 5. Prepare for Analysis
```bash
# Extract needed fields
python3 scraper_utils.py extract final.jsonl for_analysis.jsonl \
    url title content publisher published_at sentiment_score

# Split by publisher for observer analysis
python3 scraper_utils.py split for_analysis.jsonl observers/ publisher
```

### 6. Verify Results
```bash
python3 scraper_inspector.py for_analysis.jsonl --quality
```

## 🎓 For Belief Transformer Project

### Observer-Dependent Geometry Analysis

**Step 1**: Clean corpus
```bash
python3 scraper_cleaner.py scraped_news.jsonl -o corpus.jsonl
```

**Step 2**: Split by source (creates observers)
```bash
python3 scraper_utils.py split corpus.jsonl observers/ publisher
```

**Step 3**: Filter to relevant period/topics
```bash
for file in observers/*.jsonl; do
    python3 scraper_utils.py filter-theme "$file" "${file%.jsonl}_filtered.jsonl" \
        CONFLICT TERRORISM
done
```

**Step 4**: Extract for DeBERTa processing
```bash
python3 scraper_utils.py extract observers/*_filtered.jsonl bert_input.jsonl \
    url title content publisher
```

Now you have clean, organized data ready for:
- DeBERTa processing
- Multi-framing NLI
- Random observer attention analysis
- Procrustes alignment
- Geometric projection

## 🆘 Help Commands

```bash
# General help
python3 scraper_cleaner.py --help
python3 scraper_inspector.py --help
python3 scraper_utils.py --help

# Command-specific help
python3 scraper_utils.py filter-date --help
python3 scraper_utils.py merge --help
python3 scraper_utils.py split --help
```

## 📋 Quick Reference Card

| Task | Command |
|------|---------|
| Clean data | `scraper_cleaner.py input.jsonl` |
| Inspect data | `scraper_inspector.py input.jsonl --all` |
| Filter dates | `scraper_utils.py filter-date ...` |
| Filter themes | `scraper_utils.py filter-theme ...` |
| Merge files | `scraper_utils.py merge output.jsonl file1 file2...` |
| Split by field | `scraper_utils.py split input.jsonl dir/ field` |
| Extract fields | `scraper_utils.py extract input.jsonl output.jsonl f1 f2...` |
| Sample docs | `scraper_utils.py sample input.jsonl output.jsonl N` |
| Run tests | `test_tools.py` |

## 🔍 Finding What You Need

- **"How do I..."** → See QUICKSTART.md
- **"What does this field mean?"** → See README.md
- **"How does deduplication work?"** → See README.md
- **"What reports are available?"** → See scraper_inspector.py section above
- **"Show me a complete example"** → See example_pipeline.sh
- **"Something's not working"** → See QUICKSTART.md troubleshooting

## 📦 File Summary

| File | Size | Type | Priority |
|------|------|------|----------|
| **OVERVIEW.md** | 8.8KB | Doc | ⭐⭐⭐ Start here |
| **QUICKSTART.md** | 8.3KB | Doc | ⭐⭐⭐ Daily use |
| **README.md** | 9.5KB | Doc | ⭐⭐ Reference |
| **scraper_cleaner.py** | 16KB | Script | ⭐⭐⭐ Essential |
| **scraper_inspector.py** | 14KB | Script | ⭐⭐⭐ Essential |
| **scraper_utils.py** | 17KB | Script | ⭐⭐ Very useful |
| **test_tools.py** | 8.5KB | Script | ⭐ Verification |
| **example_pipeline.sh** | 4.1KB | Example | ⭐ Template |

## ✅ Installation Checklist

- [ ] All scripts are executable (`chmod +x *.py`)
- [ ] Test suite passes (`python3 test_tools.py`)
- [ ] You've read OVERVIEW.md
- [ ] You've bookmarked QUICKSTART.md
- [ ] You have sample data to test with
- [ ] You understand the basic workflow
- [ ] You know where to find help

## 🚀 You're Ready!

Start with your data:
```bash
python3 scraper_inspector.py your_data.jsonl --all
python3 scraper_cleaner.py your_data.jsonl
```

Good luck with your Belief Transformer project! 🎯
