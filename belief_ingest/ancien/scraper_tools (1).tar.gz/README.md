# Scraper Output Cleaning & Validation Tools

Two Python scripts for examining, cleaning, and validating web scraper outputs in JSONL format.

## Scripts

### 1. `scraper_cleaner.py` - Main cleaning and validation tool
- Validates required fields
- Deduplicates by ID and content hash
- Normalizes text content
- Validates dates and numeric fields
- Generates comprehensive statistics
- Saves cleaned output

### 2. `scraper_inspector.py` - Quality inspection tool
- Field coverage analysis
- Extraction quality metrics
- Malformed content detection
- Sample document viewer
- Content length distribution

## Installation

No external dependencies required - uses only Python standard library.

```bash
chmod +x scraper_cleaner.py scraper_inspector.py
```

## Usage

### Basic Cleaning

Clean a scraped dataset and save output:

```bash
python scraper_cleaner.py input_data.jsonl
```

This will:
- Load documents from `input_data.jsonl`
- Validate, deduplicate, and clean all documents
- Save cleaned output to `input_data.cleaned.jsonl`
- Print comprehensive statistics report

### Specify Custom Output Path

```bash
python scraper_cleaner.py input_data.jsonl -o clean_corpus.jsonl
```

### Analysis Only (No Output File)

```bash
python scraper_cleaner.py input_data.jsonl --analysis-only
```

### Inspection Commands

**Show all reports:**
```bash
python scraper_inspector.py input_data.jsonl --all
```

**Field coverage report:**
```bash
python scraper_inspector.py input_data.jsonl --coverage
```

**Extraction quality report:**
```bash
python scraper_inspector.py input_data.jsonl --quality
```

**Malformed content detection:**
```bash
python scraper_inspector.py input_data.jsonl --malformed
```

**View sample documents:**
```bash
python scraper_inspector.py input_data.jsonl --sample 10
```

## Data Format

Expected JSONL format (one JSON object per line):

```json
{
  "url": "https://example.com/article",
  "publisher": "example.com",
  "source_type": "gdelt",
  "published_at": "2025-10-05",
  "title": "Article Title",
  "author": "Author Name",
  "content": "Full article text...",
  "word_count": 500,
  "char_count": 3000,
  "themes": ["THEME1", "THEME2"],
  "locations": ["Location1", "Location2"],
  "sentiment_score": -2.5,
  "snippets": ["snippet 1", "snippet 2"],
  "extraction_method": "trafilatura",
  "fetched_at": "2025-11-05T17:18:05.427854",
  "id": "unique_document_id"
}
```

### Required Fields

The following fields are required for a document to pass validation:
- `url` - Document source URL
- `content` - Main text content
- `title` - Document title

### Optional Fields

All other fields are optional but will be validated if present:
- `publisher` - Publishing domain
- `source_type` - Source of the document (e.g., "gdelt")
- `published_at` - Publication date (ISO format)
- `themes` - List of theme tags
- `locations` - List of location mentions
- `sentiment_score` - Numeric sentiment (-10 to +10)
- `author` - Author name
- `word_count` - Number of words
- `char_count` - Number of characters
- `snippets` - List of text snippets
- `extraction_method` - Method used to extract text
- `fetched_at` - Timestamp when document was fetched
- `id` - Unique document identifier

## Cleaning Operations

### Text Normalization
- Removes excessive whitespace
- Removes control characters
- Trims leading/trailing whitespace
- Preserves paragraph structure

### Deduplication
- By document ID
- By content hash (MD5 of normalized content)
- Prevents processing of identical documents multiple times

### Validation
- Required field presence
- Date format validation (ISO 8601)
- Numeric field type checking
- Sentiment score range validation (-10 to +10)
- Empty content detection

### List Cleaning
- Removes empty strings from theme/location lists
- Removes duplicates while preserving order
- Cleans snippet text

## Quality Checks

### Malformed Content Detection
- HTML/XML tag presence
- JavaScript code detection
- Excessive repetition
- Binary/corrupt characters
- Word count mismatches
- Empty or very short content

### Extraction Quality Metrics
- Average content length
- Average word count
- Content length distribution
- Snippet coverage
- Metadata completeness
- Extraction method distribution

### Field Coverage Analysis
- Percentage of documents with each field populated
- Visual bar chart representation
- Sorted by coverage percentage

## Example Output

### Cleaning Report

```
======================================================================
SCRAPER OUTPUT CLEANING REPORT
======================================================================

📊 PROCESSING STATISTICS:
  Total documents processed:     15
  Valid documents:               13
  Duplicates removed:            1
  Missing required fields:       1
  Invalid dates:                 0
  Empty content after cleaning:  0
  Extraction errors:             0

📈 CORPUS ANALYSIS:
  Final document count:          13
  Average word count:            645.5
  Average character count:       4012.8
  Date range:                    2025-05-11 to 2025-10-06

🏢 TOP PUBLISHERS:
  cbsnews.com                              1
  biztoc.com                               1
  warringtonguardian.co.uk                 1
  ...

🏷️  TOP THEMES:
  WB_2432_FRAGILITY_CONFLICT_AND_VIOLENCE  8
  TAX_TERROR_GROUP_HAMAS                   7
  TERROR                                   5
  ...

😊 SENTIMENT DISTRIBUTION:
  Positive:     1
  Neutral:      3
  Negative:     9

======================================================================
```

### Inspection Report

```
======================================================================
FIELD COVERAGE REPORT
======================================================================

Total documents: 13

content                        ██████████████████████████████████████████████████ 100.00%
url                            ██████████████████████████████████████████████████ 100.00%
title                          ██████████████████████████████████████████████████ 100.00%
publisher                      ██████████████████████████████████████████████████ 100.00%
themes                         ██████████████████████████████████████████████████ 100.00%
locations                      ██████████████████████████████████████████████████ 100.00%
sentiment_score                ██████████████████████████████████████████████████ 100.00%
word_count                     ██████████████████████████████████████████████████ 100.00%
published_at                   ████████████████████████████████████████████████░░  92.31%
author                         ███████████████████████████████████████████░░░░░░░  84.62%
```

## Workflow Recommendations

### 1. Initial Inspection
```bash
# First, inspect your raw data
python scraper_inspector.py raw_data.jsonl --all
```

### 2. Cleaning
```bash
# Clean and validate
python scraper_cleaner.py raw_data.jsonl -o clean_data.jsonl
```

### 3. Verification
```bash
# Verify cleaned output
python scraper_inspector.py clean_data.jsonl --quality
```

### 4. Sample Review
```bash
# Review random samples
python scraper_inspector.py clean_data.jsonl --sample 5
```

## Tips

- **Large Files**: Both scripts stream data and work efficiently with large JSONL files
- **Deduplication**: Run cleaning on combined datasets to remove cross-file duplicates
- **Malformed Content**: Use `--malformed` flag to identify extraction issues early
- **Iterative Cleaning**: You can run the cleaner multiple times; already-clean data passes through unchanged
- **Analysis Only**: Use `--analysis-only` when you just want statistics without writing files

## Common Issues

### "Missing required fields"
Ensure your documents have at minimum: `url`, `content`, and `title` fields.

### "Invalid date format"
Dates should be in ISO 8601 format: `YYYY-MM-DD` or `YYYY-MM-DDTHH:MM:SS`

### "Duplicates detected"
This is normal - the cleaner will keep only the first occurrence. Review if unexpected.

### "Contains HTML/XML tags"
Your extraction method may not be cleaning HTML properly. Consider different extraction settings.

## Integration

These scripts can be integrated into your scraping pipeline:

```bash
# Pipeline example
./scrape.sh > raw_output.jsonl
python scraper_cleaner.py raw_output.jsonl -o corpus.jsonl
python scraper_inspector.py corpus.jsonl --quality
```

## Contributing

To extend functionality:
- Add custom validation rules to `ScraperCleaner.validate_*` methods
- Add quality checks to `DataInspector.find_malformed_content()`
- Extend analysis metrics in `analyze_corpus()`

## License

MIT License - use freely in your projects.
