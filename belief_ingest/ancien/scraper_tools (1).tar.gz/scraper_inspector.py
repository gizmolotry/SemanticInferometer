#!/usr/bin/env python3
"""
Scraper Data Inspector

Interactive utilities for examining scraper output quality and characteristics.
"""

import json
from pathlib import Path
from typing import List, Dict, Any
from collections import defaultdict
import re


class DataInspector:
    """Tools for inspecting scraper output quality."""
    
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.documents = self.load_documents()
    
    def load_documents(self) -> List[Dict[str, Any]]:
        """Load all documents from file."""
        documents = []
        with open(self.file_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        documents.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        return documents
    
    def check_field_coverage(self) -> Dict[str, float]:
        """Calculate percentage of documents with each field populated."""
        field_counts = defaultdict(int)
        total = len(self.documents)
        
        for doc in self.documents:
            for key, value in doc.items():
                if value is not None and value != '' and value != []:
                    field_counts[key] += 1
        
        coverage = {
            field: (count / total * 100) if total > 0 else 0
            for field, count in field_counts.items()
        }
        
        return dict(sorted(coverage.items(), key=lambda x: x[1], reverse=True))
    
    def find_malformed_content(self) -> List[Dict[str, Any]]:
        """Find documents with potentially malformed content."""
        issues = []
        
        for idx, doc in enumerate(self.documents):
            doc_issues = {'index': idx, 'url': doc.get('url', 'N/A'), 'problems': []}
            
            # Check for excessive repetition
            if 'content' in doc and doc['content']:
                content = doc['content']
                
                # Check for repeated phrases
                words = content.split()
                if len(words) > 50:
                    # Check for phrases repeated more than 3 times
                    for length in [3, 5, 10]:
                        for i in range(len(words) - length):
                            phrase = ' '.join(words[i:i+length])
                            if content.count(phrase) > 3:
                                doc_issues['problems'].append(
                                    f"Phrase repeated {content.count(phrase)} times: '{phrase[:50]}...'"
                                )
                                break
                
                # Check for HTML/XML tags
                if re.search(r'<[^>]+>', content):
                    doc_issues['problems'].append("Contains HTML/XML tags")
                
                # Check for JavaScript
                if 'function(' in content or 'var ' in content:
                    doc_issues['problems'].append("Contains JavaScript code")
                
                # Check for excessive newlines
                if '\n\n\n\n' in content:
                    doc_issues['problems'].append("Contains excessive newlines")
                
                # Check for binary content indicators
                if any(char in content for char in ['\x00', '\ufffd']):
                    doc_issues['problems'].append("Contains binary/corrupt characters")
            
            # Check word count vs content mismatch
            if 'word_count' in doc and 'content' in doc:
                if doc['word_count'] and doc['content']:
                    actual_words = len(doc['content'].split())
                    reported_words = doc['word_count']
                    
                    if abs(actual_words - reported_words) > 100:
                        doc_issues['problems'].append(
                            f"Word count mismatch: reported {reported_words}, actual {actual_words}"
                        )
            
            # Check for empty or very short content
            if 'content' in doc:
                if not doc['content']:
                    doc_issues['problems'].append("Empty content")
                elif len(doc['content']) < 100:
                    doc_issues['problems'].append(f"Very short content: {len(doc['content'])} chars")
            
            if doc_issues['problems']:
                issues.append(doc_issues)
        
        return issues
    
    def check_extraction_quality(self) -> Dict[str, Any]:
        """Assess overall extraction quality."""
        quality_metrics = {
            'avg_content_length': 0,
            'avg_word_count': 0,
            'documents_with_snippets': 0,
            'documents_with_metadata': 0,
            'extraction_methods': defaultdict(int),
            'content_length_distribution': {
                'very_short': 0,  # < 500 chars
                'short': 0,        # 500-2000 chars
                'medium': 0,       # 2000-5000 chars
                'long': 0,         # 5000-10000 chars
                'very_long': 0     # > 10000 chars
            }
        }
        
        total_length = 0
        total_words = 0
        
        for doc in self.documents:
            # Content length
            if 'content' in doc and doc['content']:
                length = len(doc['content'])
                total_length += length
                
                if length < 500:
                    quality_metrics['content_length_distribution']['very_short'] += 1
                elif length < 2000:
                    quality_metrics['content_length_distribution']['short'] += 1
                elif length < 5000:
                    quality_metrics['content_length_distribution']['medium'] += 1
                elif length < 10000:
                    quality_metrics['content_length_distribution']['long'] += 1
                else:
                    quality_metrics['content_length_distribution']['very_long'] += 1
            
            # Word count
            if 'word_count' in doc and doc['word_count']:
                total_words += doc['word_count']
            
            # Snippets
            if 'snippets' in doc and doc['snippets']:
                quality_metrics['documents_with_snippets'] += 1
            
            # Metadata completeness
            metadata_fields = ['publisher', 'author', 'published_at', 'themes', 'locations']
            if sum(1 for field in metadata_fields if doc.get(field)) >= 3:
                quality_metrics['documents_with_metadata'] += 1
            
            # Extraction method
            if 'extraction_method' in doc:
                quality_metrics['extraction_methods'][doc['extraction_method']] += 1
        
        if self.documents:
            quality_metrics['avg_content_length'] = total_length / len(self.documents)
            quality_metrics['avg_word_count'] = total_words / len(self.documents)
        
        return quality_metrics
    
    def find_duplicates_by_similarity(self, threshold: float = 0.9) -> List[List[int]]:
        """Find potential duplicates using simple similarity metric."""
        from difflib import SequenceMatcher
        
        duplicates = []
        checked = set()
        
        for i, doc1 in enumerate(self.documents):
            if i in checked:
                continue
            
            group = [i]
            content1 = doc1.get('content', '')
            
            if not content1 or len(content1) < 100:
                continue
            
            for j, doc2 in enumerate(self.documents[i+1:], start=i+1):
                if j in checked:
                    continue
                
                content2 = doc2.get('content', '')
                
                if not content2 or len(content2) < 100:
                    continue
                
                # Quick length check
                len_ratio = min(len(content1), len(content2)) / max(len(content1), len(content2))
                if len_ratio < 0.8:
                    continue
                
                # Calculate similarity
                similarity = SequenceMatcher(None, content1[:1000], content2[:1000]).ratio()
                
                if similarity >= threshold:
                    group.append(j)
                    checked.add(j)
            
            if len(group) > 1:
                duplicates.append(group)
                checked.update(group)
        
        return duplicates
    
    def sample_documents(self, n: int = 5) -> List[Dict[str, Any]]:
        """Get a random sample of documents for inspection."""
        import random
        
        if len(self.documents) <= n:
            return self.documents
        
        return random.sample(self.documents, n)
    
    def print_field_coverage_report(self) -> None:
        """Print field coverage report."""
        coverage = self.check_field_coverage()
        
        print("\n" + "="*70)
        print("FIELD COVERAGE REPORT")
        print("="*70)
        print(f"\nTotal documents: {len(self.documents)}\n")
        
        for field, percentage in coverage.items():
            bar_length = int(percentage / 2)
            bar = '█' * bar_length + '░' * (50 - bar_length)
            print(f"{field:30s} {bar} {percentage:6.2f}%")
    
    def print_quality_report(self) -> None:
        """Print extraction quality report."""
        metrics = self.check_extraction_quality()
        
        print("\n" + "="*70)
        print("EXTRACTION QUALITY REPORT")
        print("="*70)
        
        print(f"\n📏 CONTENT METRICS:")
        print(f"  Average content length:  {metrics['avg_content_length']:.0f} chars")
        print(f"  Average word count:      {metrics['avg_word_count']:.0f} words")
        print(f"  Documents with snippets: {metrics['documents_with_snippets']}")
        print(f"  Documents with metadata: {metrics['documents_with_metadata']}")
        
        print(f"\n📊 CONTENT LENGTH DISTRIBUTION:")
        dist = metrics['content_length_distribution']
        total = sum(dist.values())
        for category, count in dist.items():
            percentage = (count / total * 100) if total > 0 else 0
            print(f"  {category:15s} {count:5d} ({percentage:5.1f}%)")
        
        print(f"\n🔧 EXTRACTION METHODS:")
        for method, count in metrics['extraction_methods'].items():
            print(f"  {method:30s} {count:5d}")
    
    def print_malformed_content_report(self) -> None:
        """Print report of malformed content."""
        issues = self.find_malformed_content()
        
        print("\n" + "="*70)
        print("MALFORMED CONTENT REPORT")
        print("="*70)
        
        if not issues:
            print("\n✅ No malformed content detected!")
            return
        
        print(f"\n⚠️  Found {len(issues)} documents with potential issues:\n")
        
        for issue in issues[:20]:  # Limit to first 20
            print(f"Document #{issue['index']}: {issue['url'][:60]}")
            for problem in issue['problems']:
                print(f"  ⚠️  {problem}")
            print()
        
        if len(issues) > 20:
            print(f"... and {len(issues) - 20} more documents with issues")


def main():
    """Main execution function."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Inspect scraper output quality'
    )
    parser.add_argument(
        'input_file',
        help='Input JSONL file to inspect'
    )
    parser.add_argument(
        '--coverage',
        action='store_true',
        help='Show field coverage report'
    )
    parser.add_argument(
        '--quality',
        action='store_true',
        help='Show extraction quality report'
    )
    parser.add_argument(
        '--malformed',
        action='store_true',
        help='Show malformed content report'
    )
    parser.add_argument(
        '--all',
        action='store_true',
        help='Show all reports'
    )
    parser.add_argument(
        '--sample',
        type=int,
        metavar='N',
        help='Show N sample documents'
    )
    
    args = parser.parse_args()
    
    # Load inspector
    print(f"📂 Loading documents from: {args.input_file}")
    inspector = DataInspector(args.input_file)
    print(f"✅ Loaded {len(inspector.documents)} documents\n")
    
    # Show requested reports
    if args.all or args.coverage:
        inspector.print_field_coverage_report()
    
    if args.all or args.quality:
        inspector.print_quality_report()
    
    if args.all or args.malformed:
        inspector.print_malformed_content_report()
    
    if args.sample:
        samples = inspector.sample_documents(args.sample)
        print("\n" + "="*70)
        print(f"SAMPLE DOCUMENTS (n={len(samples)})")
        print("="*70)
        for i, doc in enumerate(samples, 1):
            print(f"\n--- Document {i} ---")
            print(f"URL: {doc.get('url', 'N/A')}")
            print(f"Title: {doc.get('title', 'N/A')[:80]}")
            print(f"Publisher: {doc.get('publisher', 'N/A')}")
            print(f"Word count: {doc.get('word_count', 'N/A')}")
            print(f"Content preview: {doc.get('content', '')[:200]}...")
    
    # If no flags, show all
    if not any([args.coverage, args.quality, args.malformed, args.sample, args.all]):
        inspector.print_field_coverage_report()
        inspector.print_quality_report()
        inspector.print_malformed_content_report()


if __name__ == '__main__':
    main()
