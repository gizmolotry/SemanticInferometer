#!/usr/bin/env python3
"""
Scraper Output Cleaner and Validator

This script examines and cleans JSON documents from web scraping operations.
It performs validation, deduplication, quality checks, and data normalization.
"""

import json
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Set, Tuple
from collections import Counter, defaultdict
from datetime import datetime
import re


class ScraperCleaner:
    """Clean and validate scraped document data."""
    
    def __init__(self):
        self.stats = {
            'total_docs': 0,
            'valid_docs': 0,
            'duplicates_removed': 0,
            'invalid_dates': 0,
            'missing_required_fields': 0,
            'cleaned_content': 0,
            'empty_content': 0,
            'extraction_errors': 0
        }
        
        self.required_fields = {'url', 'content', 'title'}
        self.optional_fields = {
            'publisher', 'source_type', 'published_at', 'themes', 
            'locations', 'sentiment_score', 'author', 'word_count', 
            'char_count', 'snippets', 'extraction_method', 'fetched_at', 'id'
        }
        
        self.seen_ids = set()
        self.seen_content_hashes = set()
        
    def load_documents(self, file_path: str) -> List[Dict[str, Any]]:
        """Load documents from a JSONL file."""
        documents = []
        
        with open(file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                    
                try:
                    doc = json.loads(line)
                    documents.append(doc)
                except json.JSONDecodeError as e:
                    print(f"⚠️  Line {line_num}: Invalid JSON - {e}")
                    self.stats['extraction_errors'] += 1
                    
        self.stats['total_docs'] = len(documents)
        return documents
    
    def validate_required_fields(self, doc: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Check if document has all required fields."""
        missing = []
        for field in self.required_fields:
            if field not in doc or doc[field] is None or doc[field] == '':
                missing.append(field)
        
        return len(missing) == 0, missing
    
    def validate_date(self, date_str: str) -> bool:
        """Validate date format."""
        if not date_str:
            return False
            
        # Common date formats
        formats = [
            '%Y-%m-%d',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%S.%f',
            '%Y-%m-%dT%H:%M:%SZ',
            '%Y-%m-%dT%H:%M:%S.%fZ'
        ]
        
        for fmt in formats:
            try:
                datetime.strptime(date_str, fmt)
                return True
            except ValueError:
                continue
                
        return False
    
    def calculate_content_hash(self, content: str) -> str:
        """Calculate hash of content for deduplication."""
        # Normalize content: lowercase, remove extra whitespace
        normalized = re.sub(r'\s+', ' ', content.lower().strip())
        return hashlib.md5(normalized.encode()).hexdigest()
    
    def is_duplicate(self, doc: Dict[str, Any]) -> Tuple[bool, str]:
        """Check if document is a duplicate."""
        # Check by ID
        if 'id' in doc and doc['id'] in self.seen_ids:
            return True, 'id'
        
        # Check by content hash
        if 'content' in doc:
            content_hash = self.calculate_content_hash(doc['content'])
            if content_hash in self.seen_content_hashes:
                return True, 'content'
            
        return False, ''
    
    def mark_as_seen(self, doc: Dict[str, Any]) -> None:
        """Mark document as seen for deduplication."""
        if 'id' in doc:
            self.seen_ids.add(doc['id'])
        
        if 'content' in doc:
            content_hash = self.calculate_content_hash(doc['content'])
            self.seen_content_hashes.add(content_hash)
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text content."""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove control characters
        text = ''.join(char for char in text if ord(char) >= 32 or char in '\n\t')
        
        # Strip leading/trailing whitespace
        text = text.strip()
        
        return text
    
    def validate_sentiment_score(self, score: Any) -> bool:
        """Validate sentiment score is a reasonable number."""
        try:
            score_float = float(score)
            # Typical sentiment scores range from -10 to +10
            return -10 <= score_float <= 10
        except (ValueError, TypeError):
            return False
    
    def clean_document(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        """Clean and normalize a single document."""
        cleaned = doc.copy()
        
        # Clean text fields
        text_fields = ['content', 'title', 'author']
        for field in text_fields:
            if field in cleaned and cleaned[field]:
                cleaned[field] = self.clean_text(cleaned[field])
                
                # Check for empty content after cleaning
                if field == 'content' and not cleaned[field]:
                    self.stats['empty_content'] += 1
        
        # Clean snippets
        if 'snippets' in cleaned and isinstance(cleaned['snippets'], list):
            cleaned['snippets'] = [
                self.clean_text(snippet) 
                for snippet in cleaned['snippets'] 
                if snippet
            ]
        
        # Validate and clean numeric fields
        if 'word_count' in cleaned:
            try:
                cleaned['word_count'] = int(cleaned['word_count'])
            except (ValueError, TypeError):
                cleaned['word_count'] = None
        
        if 'char_count' in cleaned:
            try:
                cleaned['char_count'] = int(cleaned['char_count'])
            except (ValueError, TypeError):
                cleaned['char_count'] = None
        
        # Validate sentiment score
        if 'sentiment_score' in cleaned:
            if not self.validate_sentiment_score(cleaned['sentiment_score']):
                cleaned['sentiment_score'] = None
        
        # Clean theme and location lists
        for field in ['themes', 'locations']:
            if field in cleaned and isinstance(cleaned[field], list):
                # Remove empty strings and duplicates while preserving order
                seen = set()
                cleaned_list = []
                for item in cleaned[field]:
                    if item and item not in seen:
                        seen.add(item)
                        cleaned_list.append(item)
                cleaned[field] = cleaned_list
        
        self.stats['cleaned_content'] += 1
        return cleaned
    
    def process_documents(self, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Process all documents: validate, deduplicate, and clean."""
        cleaned_docs = []
        
        for idx, doc in enumerate(documents, 1):
            # Validate required fields
            valid, missing = self.validate_required_fields(doc)
            if not valid:
                print(f"⚠️  Doc {idx}: Missing required fields: {missing}")
                self.stats['missing_required_fields'] += 1
                continue
            
            # Check for duplicates
            is_dup, dup_type = self.is_duplicate(doc)
            if is_dup:
                self.stats['duplicates_removed'] += 1
                print(f"⚠️  Doc {idx}: Duplicate detected (by {dup_type})")
                continue
            
            # Mark as seen
            self.mark_as_seen(doc)
            
            # Validate date if present
            if 'published_at' in doc:
                if not self.validate_date(doc['published_at']):
                    print(f"⚠️  Doc {idx}: Invalid date format: {doc.get('published_at')}")
                    self.stats['invalid_dates'] += 1
            
            # Clean document
            cleaned_doc = self.clean_document(doc)
            cleaned_docs.append(cleaned_doc)
            self.stats['valid_docs'] += 1
        
        return cleaned_docs
    
    def analyze_corpus(self, documents: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate statistical analysis of the corpus."""
        analysis = {
            'total_documents': len(documents),
            'publishers': Counter(),
            'source_types': Counter(),
            'extraction_methods': Counter(),
            'themes': Counter(),
            'locations': Counter(),
            'avg_word_count': 0,
            'avg_char_count': 0,
            'date_range': {'earliest': None, 'latest': None},
            'sentiment_distribution': {
                'positive': 0,
                'negative': 0,
                'neutral': 0
            }
        }
        
        word_counts = []
        char_counts = []
        dates = []
        
        for doc in documents:
            # Count publishers
            if 'publisher' in doc and doc['publisher']:
                analysis['publishers'][doc['publisher']] += 1
            
            # Count source types
            if 'source_type' in doc and doc['source_type']:
                analysis['source_types'][doc['source_type']] += 1
            
            # Count extraction methods
            if 'extraction_method' in doc and doc['extraction_method']:
                analysis['extraction_methods'][doc['extraction_method']] += 1
            
            # Count themes
            if 'themes' in doc and isinstance(doc['themes'], list):
                for theme in doc['themes']:
                    analysis['themes'][theme] += 1
            
            # Count locations
            if 'locations' in doc and isinstance(doc['locations'], list):
                for location in doc['locations']:
                    analysis['locations'][location] += 1
            
            # Collect word and char counts
            if 'word_count' in doc and doc['word_count']:
                word_counts.append(doc['word_count'])
            
            if 'char_count' in doc and doc['char_count']:
                char_counts.append(doc['char_count'])
            
            # Collect dates
            if 'published_at' in doc and doc['published_at']:
                dates.append(doc['published_at'])
            
            # Sentiment distribution
            if 'sentiment_score' in doc and doc['sentiment_score'] is not None:
                score = doc['sentiment_score']
                if score > 1:
                    analysis['sentiment_distribution']['positive'] += 1
                elif score < -1:
                    analysis['sentiment_distribution']['negative'] += 1
                else:
                    analysis['sentiment_distribution']['neutral'] += 1
        
        # Calculate averages
        if word_counts:
            analysis['avg_word_count'] = sum(word_counts) / len(word_counts)
        
        if char_counts:
            analysis['avg_char_count'] = sum(char_counts) / len(char_counts)
        
        # Date range
        if dates:
            analysis['date_range']['earliest'] = min(dates)
            analysis['date_range']['latest'] = max(dates)
        
        return analysis
    
    def print_report(self, analysis: Dict[str, Any]) -> None:
        """Print a comprehensive report of the cleaning process."""
        print("\n" + "="*70)
        print("SCRAPER OUTPUT CLEANING REPORT")
        print("="*70)
        
        print("\n📊 PROCESSING STATISTICS:")
        print(f"  Total documents processed:     {self.stats['total_docs']}")
        print(f"  Valid documents:               {self.stats['valid_docs']}")
        print(f"  Duplicates removed:            {self.stats['duplicates_removed']}")
        print(f"  Missing required fields:       {self.stats['missing_required_fields']}")
        print(f"  Invalid dates:                 {self.stats['invalid_dates']}")
        print(f"  Empty content after cleaning:  {self.stats['empty_content']}")
        print(f"  Extraction errors:             {self.stats['extraction_errors']}")
        
        print("\n📈 CORPUS ANALYSIS:")
        print(f"  Final document count:          {analysis['total_documents']}")
        print(f"  Average word count:            {analysis['avg_word_count']:.1f}")
        print(f"  Average character count:       {analysis['avg_char_count']:.1f}")
        
        if analysis['date_range']['earliest']:
            print(f"  Date range:                    {analysis['date_range']['earliest']} to {analysis['date_range']['latest']}")
        
        print("\n🏢 TOP PUBLISHERS:")
        for publisher, count in analysis['publishers'].most_common(10):
            print(f"  {publisher:40s} {count:5d}")
        
        print("\n📰 SOURCE TYPES:")
        for source_type, count in analysis['source_types'].most_common():
            print(f"  {source_type:40s} {count:5d}")
        
        print("\n🏷️  TOP THEMES:")
        for theme, count in analysis['themes'].most_common(15):
            print(f"  {theme:50s} {count:5d}")
        
        print("\n🌍 TOP LOCATIONS:")
        for location, count in analysis['locations'].most_common(15):
            print(f"  {location:50s} {count:5d}")
        
        print("\n😊 SENTIMENT DISTRIBUTION:")
        sent = analysis['sentiment_distribution']
        print(f"  Positive: {sent['positive']:5d}")
        print(f"  Neutral:  {sent['neutral']:5d}")
        print(f"  Negative: {sent['negative']:5d}")
        
        print("\n" + "="*70)
    
    def save_cleaned_documents(self, documents: List[Dict[str, Any]], output_path: str) -> None:
        """Save cleaned documents to a JSONL file."""
        with open(output_path, 'w', encoding='utf-8') as f:
            for doc in documents:
                f.write(json.dumps(doc, ensure_ascii=False) + '\n')
        
        print(f"\n✅ Saved {len(documents)} cleaned documents to: {output_path}")


def main():
    """Main execution function."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Clean and validate scraped document data'
    )
    parser.add_argument(
        'input_file',
        help='Input JSONL file containing scraped documents'
    )
    parser.add_argument(
        '-o', '--output',
        help='Output file for cleaned documents (default: input_file.cleaned.jsonl)'
    )
    parser.add_argument(
        '--analysis-only',
        action='store_true',
        help='Only perform analysis without saving cleaned data'
    )
    
    args = parser.parse_args()
    
    # Determine output path
    if args.output:
        output_path = args.output
    else:
        input_path = Path(args.input_file)
        output_path = input_path.parent / f"{input_path.stem}.cleaned.jsonl"
    
    # Initialize cleaner
    cleaner = ScraperCleaner()
    
    # Load documents
    print(f"📂 Loading documents from: {args.input_file}")
    documents = cleaner.load_documents(args.input_file)
    
    # Process documents
    print(f"🔧 Processing {len(documents)} documents...")
    cleaned_docs = cleaner.process_documents(documents)
    
    # Analyze corpus
    print(f"📊 Analyzing corpus...")
    analysis = cleaner.analyze_corpus(cleaned_docs)
    
    # Print report
    cleaner.print_report(analysis)
    
    # Save cleaned documents
    if not args.analysis_only:
        cleaner.save_cleaned_documents(cleaned_docs, str(output_path))
    else:
        print("\n⚠️  Analysis-only mode: cleaned documents not saved")


if __name__ == '__main__':
    main()
