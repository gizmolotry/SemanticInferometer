# LOGITS MIGRATION - QUICKSTART GUIDE

## What You Need To Download

Download these 4 files from Claude and put them in `D:\belief-transformer\V3\`:

1. **nli_extraction_logits.py** - New extractor using logits
2. **framing_queries_improved.yaml** - Better asymmetric queries  
3. **test_logits_improved.py** - Test script
4. **setup_logits.py** - Setup script

## Step-by-Step

### 1. Place downloaded files
```bash
# All 4 files should be in:
D:\belief-transformer\V3\
```

### 2. Run setup
```bash
cd D:\belief-transformer\V3
python setup_logits.py
```

This will:
- Copy `nli_extraction_logits.py` → `core/nli_extraction_logits.py`
- Copy `framing_queries_improved.yaml` → `config/framing_queries_improved.yaml`
- Leave `test_logits_improved.py` in V3/

### 3. Test the new approach
```bash
python test_logits_improved.py
```

**Expected output:**
```
Pro-Israel vs Pro-Palestinian: 0.20-0.50  ← GOOD!
✓✓✓ EXCELLENT: Opposite articles very different
```

### 4. If test succeeds, deploy
```bash
# Backup old extractor
copy core\nli_extraction.py core\nli_extraction_OLD.py

# Replace with logits version
copy core\nli_extraction_logits.py core\nli_extraction.py

# Backup old queries
copy config\framing_queries.yaml config\framing_queries_OLD.yaml

# Replace with improved queries
copy config\framing_queries_improved.yaml config\framing_queries.yaml

# Delete old cache (CRITICAL)
del outputs\nli_cache_*.pt
```

### 5. Update feature dimensions

Edit `core/complete_pipeline.py` around line 90:

```python
# OLD:
feature_dim = n_framings * embedding_dim  # 8 * 1536 = 12288

# NEW:
feature_dim = n_framings * 3  # 8 * 3 = 24
```

### 6. Re-run experiments
```bash
# All old observer files are invalid now
del outputs\observer_*.pt
del outputs\diverse_observer_*.pt
del outputs\shuffle_observer_*.pt

# Run with new system
python run_diverse_experiments.py --corpus real --mode diverse
```

---

## What Changed

**Before:**
- NLI extractor used CLS embeddings (1536D per framing)
- Total features: 8 framings × 1536D = 12,288D
- Symmetric queries ("Israel responsible" vs "Hamas responsible")
- Result: 99%+ similarity even for opposites

**After:**
- NLI extractor uses logits (3D per framing: contradiction/neutral/entailment)
- Total features: 8 framings × 3D = 24D
- Asymmetric queries ("justifies Israeli" vs "condemns Israeli")  
- Result: <50% similarity for opposites ✓

---

## Troubleshooting

**"ModuleNotFoundError: nli_extraction_logits"**
→ Run `setup_logits.py` first

**"FileNotFoundError: framing_queries_improved.yaml"**
→ Make sure it's in `config/` not root

**Test still shows high similarity (>0.7)**
→ Delete `outputs/nli_cache_*.pt` and try again

---

## Rollback If Needed

```bash
# Restore original extractor
copy core\nli_extraction_OLD.py core\nli_extraction.py

# Restore original queries
copy config\framing_queries_OLD.yaml config\framing_queries.yaml
```
