"""
Fix the double-Logits bug in complete_pipeline_diverse_FIXED.py
"""

print("Fixing double-Logits bug...")

with open('complete_pipeline_diverse_FIXED.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix the double-Logits
content = content.replace('MultiFramingNLIExtractorLogitsLogits', 'MultiFramingNLIExtractorLogits')

with open('complete_pipeline_diverse_FIXED.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fixed! Changed LogitsLogits → Logits")
