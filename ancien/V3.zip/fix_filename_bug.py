"""
Fix filename bug in complete_pipeline_diverse_FIXED.py

Current: All corpuses save as diverse_observer_{seed}.pt
Fixed: Save as diverse_observer_{corpus_type}_{seed}.pt
"""

import sys

print("="*70)
print("FIXING FILENAME BUG IN complete_pipeline_diverse_FIXED.py")
print("="*70)

try:
    with open('complete_pipeline_diverse_FIXED.py', 'r', encoding='utf-8') as f:
        lines = f.readlines()
except FileNotFoundError:
    print("\n✗ ERROR: complete_pipeline_diverse_FIXED.py not found!")
    sys.exit(1)

fixed_lines = []
for i, line in enumerate(lines, 1):
    # Find the line that saves the output file
    if "output_file = f'outputs/diverse_observer_{seed}.pt'" in line:
        indent = len(line) - len(line.lstrip())
        # Insert corpus type into filename
        fixed_lines.append(' ' * indent + "corpus_type = result.get('corpus_name', 'unknown')\n")
        fixed_lines.append(' ' * indent + f"output_file = f'outputs/diverse_observer_{{corpus_type}}_{{seed}}.pt'\n")
        print(f"  ✓ Fixed line {i}: Added corpus_type to filename")
    else:
        fixed_lines.append(line)

with open('complete_pipeline_diverse_FIXED.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed_lines)

print("\n✓ Filename bug fixed!")
print("\nFiles will now save as:")
print("  - outputs/diverse_observer_gaza_israel_{seed}.pt  (real corpus)")
print("  - outputs/diverse_observer_shuffle_{seed}.pt      (shuffle corpus)")

print("\n" + "="*70)
print("NOW YOU NEED TO:")
print("="*70)
print("\n1. Re-run REAL corpus (shuffle overwrote it):")
print("   python run_diverse_experiments.py --corpus real --mode diverse")
print("\n2. Then run shuffle again (with correct filenames):")
print("   python run_diverse_experiments.py --corpus shuffle --mode diverse")
print("\n3. Then compare:")
print("   python compare_real_shuffle_random.py")
print("="*70)
