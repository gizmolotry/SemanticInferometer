"""
Auto-fix complete_pipeline_diverse_FIXED.py to use compatible num_heads

With 24D features, num_heads must divide evenly into 24.
Using 6 heads (24/6 = 4 dims per head).
"""

import sys

print("="*70)
print("PATCHING complete_pipeline_diverse_FIXED.py - num_heads fix")
print("="*70)

try:
    with open('complete_pipeline_diverse_FIXED.py', 'r', encoding='utf-8') as f:
        content = f.read()
except FileNotFoundError:
    print("\n✗ ERROR: complete_pipeline_diverse_FIXED.py not found!")
    print("Are you in D:\\belief-transformer\\V3?")
    sys.exit(1)

# Replace num_heads=8 with num_heads=6
# 24D / 6 heads = 4 dims per head ✓
original = content
content = content.replace('num_heads=8', 'num_heads=6')

if content == original:
    print("\n⚠ No changes made - might already be fixed")
else:
    with open('complete_pipeline_diverse_FIXED.py', 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("\n✓ Changed num_heads from 8 to 6")
    print("  24D features / 6 heads = 4 dims per head ✓")

print("\n" + "="*70)
print("Now run:")
print("  python run_diverse_experiments.py --corpus real --mode diverse")
print("="*70)
