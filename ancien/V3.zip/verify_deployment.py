"""
Verify Logits Deployment

Quick check that everything is correctly set up.
"""

import os
import sys
from pathlib import Path

print("="*70)
print("VERIFICATION: LOGITS-BASED SYSTEM")
print("="*70)

all_good = True

# Check 1: Files exist
print("\n[1/4] Checking required files...")
required = {
    'core/nli_extraction_logits.py': False,
    'core/complete_pipeline.py': False,
    'config/framing_queries.yaml': False
}

for fpath in required:
    if os.path.exists(fpath):
        required[fpath] = True
        print(f"  ✓ {fpath}")
    else:
        required[fpath] = False
        print(f"  ✗ {fpath} MISSING")
        all_good = False

# Check 2: Imports work
print("\n[2/4] Checking imports...")
try:
    from core.nli_extraction_logits import MultiFramingNLIExtractorLogits
    print("  ✓ Can import MultiFramingNLIExtractorLogits")
except Exception as e:
    print(f"  ✗ Cannot import: {e}")
    all_good = False

try:
    from core.complete_pipeline import initialize_full_pipeline
    print("  ✓ Can import initialize_full_pipeline")
except Exception as e:
    print(f"  ✗ Cannot import: {e}")
    all_good = False

# Check 3: Complete pipeline uses logits
print("\n[3/4] Verifying complete_pipeline uses logits...")
with open('core/complete_pipeline.py', 'r', encoding='utf-8') as f:
    content = f.read()
    
if 'nli_extraction_logits' in content:
    print("  ✓ complete_pipeline imports nli_extraction_logits")
elif 'MultiFramingNLIExtractorLogits' in content:
    print("  ✓ complete_pipeline uses MultiFramingNLIExtractorLogits")
else:
    print("  ✗ complete_pipeline still using old NLI extractor!")
    print("    Run deploy_logits.py to fix")
    all_good = False

if 'feature_dim = n_framings * 3' in content:
    print("  ✓ Feature dimension set to n_framings * 3 (logits)")
elif 'logits_dim = 3' in content:
    print("  ✓ Feature dimension uses logits_dim = 3")
else:
    print("  ✗ Feature dimension still using old calculation!")
    print("    Should be: feature_dim = n_framings * 3")
    all_good = False

# Check 4: Framing queries
print("\n[4/4] Checking framing queries...")
try:
    import yaml
    with open('config/framing_queries.yaml', 'r') as f:
        queries = yaml.safe_load(f)
    
    if 'queries' in queries:
        n_queries = len(queries['queries'])
        print(f"  ✓ Found {n_queries} framing queries")
        
        # Check if using improved queries
        first_query = list(queries['queries'].values())[0]
        hypothesis = first_query.get('hypothesis', '')
        
        if 'justif' in hypothesis.lower() or 'condemn' in hypothesis.lower():
            print("  ✓ Using improved asymmetric queries")
        else:
            print("  ⚠ Queries might be old symmetric version")
            print(f"    First query: {hypothesis[:60]}...")
    else:
        print("  ✗ Invalid YAML structure")
        all_good = False
        
except Exception as e:
    print(f"  ✗ Cannot read queries: {e}")
    all_good = False

# Summary
print("\n" + "="*70)
if all_good:
    print("✓✓✓ ALL CHECKS PASSED")
    print("="*70)
    print("\nSystem is correctly configured for logits-based extraction.")
    print("\nNext steps:")
    print("  1. Test: python test_logits_improved.py")
    print("  2. Run: python run_diverse_experiments.py --corpus real --mode diverse")
else:
    print("✗✗✗ SOME CHECKS FAILED")
    print("="*70)
    print("\nFix the issues above, then run verification again.")
    print("\nTo deploy:")
    print("  python deploy_logits.py")

print("\n" + "="*70)
