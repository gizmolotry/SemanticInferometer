"""
Master Experimental Runner

Coordinates the complete Belief Transformer experimental pipeline:
1. Real corpus → multi-observer
2. Control corpus → multi-observer  
3. Temporal slices → multi-observer
4. Procrustes comparison across all conditions
"""

import sys
sys.path.append('.')

import json
import torch
from pathlib import Path
from core.complete_pipeline import run_multi_observer_experiment
from core.provenance import build_metadata_indices


def load_articles(filepath):
    """Load articles from JSONL."""
    articles = []
    with open(filepath) as f:
        for line in f:
            articles.append(json.loads(line))
    return articles


def run_real_corpus_experiment(seeds=[42, 43, 44, 45, 46]):
    """Run experiment on real Gaza/Israel corpus."""
    print("\n" + "="*70)
    print("EXPERIMENT 1: REAL CORPUS")
    print("="*70)
    
    # Load real articles
    articles = load_articles('data/scraped_articles.jsonl')
    print(f"Loaded {len(articles)} real articles")
    
    # Run multi-observer
    results = run_multi_observer_experiment(
        articles=articles,
        seeds=seeds,
        use_gru=True,
        use_framing_rope=True,
        device='cuda',
        nli_model_name='microsoft/deberta-v3-large'
    )
    
    # Tag results
    for seed, result in results.items():
        result['corpus_type'] = 'real'
        result['corpus_name'] = 'gaza_israel'
        torch.save(result, f'outputs/real_observer_{seed}.pt')
    
    print("\n✓ Real corpus experiment complete")
    return results


def run_control_corpus_experiment(seeds=[42, 43, 44, 45, 46]):
    """Run experiment on control corpus."""
    print("\n" + "="*70)
    print("EXPERIMENT 2: CONTROL CORPUS")
    print("="*70)
    
    # Load control articles
    control_path = 'data/control_corpus.jsonl'
    if not Path(control_path).exists():
        print("✗ Control corpus not found. Run make_control_corpus.py first.")
        return None
    
    articles = load_articles(control_path)
    print(f"Loaded {len(articles)} control articles")
    
    # Count by class
    from collections import Counter
    classes = Counter(a['control_class'] for a in articles)
    print("\nControl classes:")
    for cls, count in classes.items():
        print(f"  {cls:12s}: {count:4d}")
    
    # Run multi-observer
    results = run_multi_observer_experiment(
        articles=articles,
        seeds=seeds,
        use_gru=True,
        use_framing_rope=True,
        device='cuda',
        nli_model_name='microsoft/deberta-v3-large'
    )
    
    # Tag results
    for seed, result in results.items():
        result['corpus_type'] = 'control'
        result['corpus_name'] = 'three_class'
        torch.save(result, f'outputs/control_observer_{seed}.pt')
    
    print("\n✓ Control corpus experiment complete")
    return results


def run_temporal_experiment(slice_name, seeds=[42, 43, 44, 45, 46]):
    """Run experiment on a specific temporal slice."""
    print("\n" + "="*70)
    print(f"EXPERIMENT: TEMPORAL SLICE - {slice_name}")
    print("="*70)
    
    # Load temporal slice
    temporal_path = f'data/temporal/{slice_name}.jsonl'
    if not Path(temporal_path).exists():
        print(f"✗ Temporal slice not found: {temporal_path}")
        print("  Run scrape_temporal.py first.")
        return None
    
    articles = load_articles(temporal_path)
    print(f"Loaded {len(articles)} articles from {slice_name}")
    
    # Run multi-observer
    results = run_multi_observer_experiment(
        articles=articles,
        seeds=seeds,
        use_gru=True,
        use_framing_rope=True,
        device='cuda',
        nli_model_name='microsoft/deberta-v3-large'
    )
    
    # Tag results
    for seed, result in results.items():
        result['corpus_type'] = 'temporal'
        result['corpus_name'] = slice_name
        torch.save(result, f'outputs/temporal_{slice_name}_observer_{seed}.pt')
    
    print(f"\n✓ Temporal experiment complete: {slice_name}")
    return results


def run_all_temporal_experiments(seeds=[42, 43, 44, 45, 46]):
    """Run experiments on all temporal slices."""
    from scrape_temporal import define_temporal_slices
    
    slices = define_temporal_slices()
    
    results = {}
    for slice_config in slices:
        slice_results = run_temporal_experiment(slice_config['name'], seeds=seeds)
        if slice_results:
            results[slice_config['name']] = slice_results
    
    return results


def compare_all_experiments():
    """Run Procrustes comparison across all experiments."""
    print("\n" + "="*70)
    print("CROSS-EXPERIMENT COMPARISON")
    print("="*70)
    
    # Import comparison tools
    from compare_observers import (
        load_all_observers,
        pairwise_procrustes_comparison,
        identify_high_divergence_articles
    )
    
    # Load all observers
    all_files = list(Path('outputs').glob('*observer_*.pt'))
    
    print(f"\nFound {len(all_files)} observer files:")
    
    # Group by corpus type
    by_corpus = {}
    for fpath in all_files:
        obs = torch.load(fpath)
        corpus_type = obs.get('corpus_type', 'unknown')
        corpus_name = obs.get('corpus_name', 'unknown')
        key = f"{corpus_type}_{corpus_name}"
        
        if key not in by_corpus:
            by_corpus[key] = []
        by_corpus[key].append(fpath)
    
    for key, files in by_corpus.items():
        print(f"  {key:30s}: {len(files)} files")
    
    # Compare each corpus type separately
    import pandas as pd
    all_comparisons = []
    
    for corpus_key, files in by_corpus.items():
        print(f"\n{'='*70}")
        print(f"Analyzing: {corpus_key}")
        print(f"{'='*70}")
        
        # Load observers for this corpus
        observers = {}
        for fpath in files:
            seed = int(fpath.stem.split('_')[-1])
            observers[seed] = torch.load(fpath)
        
        if len(observers) < 2:
            print("  ⚠ Need at least 2 observers for comparison")
            continue
        
        # Run Procrustes
        df = pairwise_procrustes_comparison(observers, mode='umap')
        df['corpus_type'] = corpus_key
        all_comparisons.append(df)
    
    # Combine all comparisons
    if all_comparisons:
        combined = pd.concat(all_comparisons, ignore_index=True)
        combined.to_csv('outputs/all_procrustes_comparisons.csv', index=False)
        print(f"\n→ Saved combined comparisons to outputs/all_procrustes_comparisons.csv")
        
        # Summary stats
        print("\n" + "="*70)
        print("RESIDUAL SUMMARY")
        print("="*70)
        
        summary = combined.groupby('corpus_type')['residual_mean'].agg(['mean', 'std', 'min', 'max'])
        print("\n" + summary.to_string())


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Master experimental runner')
    parser.add_argument('--mode', type=str, default='all',
                       choices=['all', 'real', 'control', 'temporal', 'compare'],
                       help='Which experiments to run')
    parser.add_argument('--seeds', type=int, nargs='+', default=[42, 43, 44, 45, 46],
                       help='Observer seeds')
    
    args = parser.parse_args()
    
    print("="*70)
    print("MASTER EXPERIMENTAL RUNNER")
    print("="*70)
    print(f"\nMode: {args.mode}")
    print(f"Seeds: {args.seeds}")
    
    if args.mode == 'real' or args.mode == 'all':
        run_real_corpus_experiment(seeds=args.seeds)
    
    if args.mode == 'control' or args.mode == 'all':
        run_control_corpus_experiment(seeds=args.seeds)
    
    if args.mode == 'temporal' or args.mode == 'all':
        run_all_temporal_experiments(seeds=args.seeds)
    
    if args.mode == 'compare' or args.mode == 'all':
        compare_all_experiments()
    
    print("\n" + "="*70)
    print("✓ ALL EXPERIMENTS COMPLETE")
    print("="*70)


if __name__ == "__main__":
    main()
