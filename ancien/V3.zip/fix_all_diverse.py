"""
ALL-IN-ONE FIX FOR DIVERSE EXPERIMENTS

Fixes:
1. complete_pipeline_diverse_FIXED.py - use logits extractor
2. pipeline_enhanced.py - change num_heads from 8 to 6
3. Both core/complete_pipeline.py files - change num_heads from 8 to 6

Run this once to fix everything!
"""

import sys
import os

print("="*70)
print("ALL-IN-ONE FIX: LOGITS + NUM_HEADS")
print("="*70)

errors = []
fixed = []

# Fix 1: complete_pipeline_diverse_FIXED.py
print("\n[1/3] Fixing complete_pipeline_diverse_FIXED.py...")
try:
    with open('complete_pipeline_diverse_FIXED.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    changed = False
    
    # Fix import
    if 'from core.nli_extraction import MultiFramingNLIExtractor' in content:
        content = content.replace(
            'from core.nli_extraction import MultiFramingNLIExtractor',
            'from core.nli_extraction import MultiFramingNLIExtractorLogits'
        )
        changed = True
        print("  ✓ Fixed import")
    
    # Fix instantiation
    if 'nli_extractor = MultiFramingNLIExtractor(' in content:
        content = content.replace(
            'nli_extractor = MultiFramingNLIExtractor(',
            'nli_extractor = MultiFramingNLIExtractorLogits('
        )
        changed = True
        print("  ✓ Fixed instantiation")
    
    if changed:
        with open('complete_pipeline_diverse_FIXED.py', 'w', encoding='utf-8') as f:
            f.write(content)
        fixed.append('complete_pipeline_diverse_FIXED.py')
    else:
        print("  ⚠ Already fixed or not found")
        
except FileNotFoundError:
    errors.append('complete_pipeline_diverse_FIXED.py not found')
    print("  ✗ File not found")

# Fix 2: pipeline_enhanced.py
print("\n[2/3] Fixing pipeline_enhanced.py...")
try:
    with open('pipeline_enhanced.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    import re
    original = content
    content = re.sub(r"'num_heads':\s*8", "'num_heads': 6", content)
    content = re.sub(r'"num_heads":\s*8', '"num_heads": 6', content)
    
    if content != original:
        with open('pipeline_enhanced.py', 'w', encoding='utf-8') as f:
            f.write(content)
        fixed.append('pipeline_enhanced.py')
        print("  ✓ Changed num_heads 8→6")
    else:
        print("  ⚠ No changes (might already be 6 or use different format)")
        
except FileNotFoundError:
    errors.append('pipeline_enhanced.py not found')
    print("  ✗ File not found")

# Fix 3: core/complete_pipeline.py
print("\n[3/3] Fixing core/complete_pipeline.py...")
try:
    with open('core/complete_pipeline.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    if 'num_heads=8' in content:
        content = content.replace('num_heads=8', 'num_heads=6')
        with open('core/complete_pipeline.py', 'w', encoding='utf-8') as f:
            f.write(content)
        fixed.append('core/complete_pipeline.py')
        print("  ✓ Changed num_heads 8→6")
    else:
        print("  ⚠ Already fixed or not found")
        
except FileNotFoundError:
    errors.append('core/complete_pipeline.py not found')
    print("  ✗ File not found")

# Summary
print("\n" + "="*70)
if errors:
    print("COMPLETED WITH ERRORS")
    print("="*70)
    for err in errors:
        print(f"  ✗ {err}")
else:
    print("ALL FIXES APPLIED SUCCESSFULLY!")
    print("="*70)
    
if fixed:
    print("\nFixed files:")
    for f in fixed:
        print(f"  ✓ {f}")

print("\n" + "="*70)
print("Now run:")
print("  python run_diverse_experiments.py --corpus real --mode diverse")
print("="*70)
